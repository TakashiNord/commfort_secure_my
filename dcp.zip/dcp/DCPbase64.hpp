// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dcpbase64.pas' rev: 21.00

#ifndef Dcpbase64HPP
#define Dcpbase64HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dcpbase64
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
extern PACKAGE int __fastcall Base64Encode(void * pInput, void * pOutput, int Size);
extern PACKAGE System::AnsiString __fastcall Base64EncodeStr(const System::AnsiString Value)/* overload */;
extern PACKAGE System::UnicodeString __fastcall Base64EncodeStr(const System::UnicodeString Value)/* overload */;
extern PACKAGE int __fastcall Base64Decode(void * pInput, void * pOutput, int Size);
extern PACKAGE System::AnsiString __fastcall Base64DecodeStr(const System::AnsiString Value)/* overload */;
extern PACKAGE System::UnicodeString __fastcall Base64DecodeStr(const System::UnicodeString Value)/* overload */;

}	/* namespace Dcpbase64 */
using namespace Dcpbase64;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Dcpbase64HPP
