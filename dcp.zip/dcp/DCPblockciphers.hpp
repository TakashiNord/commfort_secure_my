// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dcpblockciphers.pas' rev: 21.00

#ifndef DcpblockciphersHPP
#define DcpblockciphersHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Dcpcrypt2.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dcpblockciphers
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDCP_blockcipher64;
class PASCALIMPLEMENTATION TDCP_blockcipher64 : public Dcpcrypt2::TDCP_blockcipher
{
	typedef Dcpcrypt2::TDCP_blockcipher inherited;
	
private:
	StaticArray<System::Byte, 8> IV;
	StaticArray<System::Byte, 8> CV;
	void __fastcall IncCounter(void);
	
public:
	__classmethod virtual int __fastcall GetBlockSize();
	virtual void __fastcall Reset(void);
	virtual void __fastcall Burn(void);
	virtual void __fastcall SetIV(const void *Value);
	virtual void __fastcall GetIV(void *Value);
	virtual void __fastcall Init(const void *Key, unsigned Size, void * InitVector);
	virtual void __fastcall EncryptCBC(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCBC(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptCFB8bit(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCFB8bit(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptCFBblock(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCFBblock(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptOFB(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptOFB(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptCTR(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCTR(const void *Indata, void *Outdata, unsigned Size);
public:
	/* TDCP_blockcipher.Create */ inline __fastcall virtual TDCP_blockcipher64(Classes::TComponent* AOwner) : Dcpcrypt2::TDCP_blockcipher(AOwner) { }
	
public:
	/* TDCP_cipher.Destroy */ inline __fastcall virtual ~TDCP_blockcipher64(void) { }
	
};


class DELPHICLASS TDCP_blockcipher128;
class PASCALIMPLEMENTATION TDCP_blockcipher128 : public Dcpcrypt2::TDCP_blockcipher
{
	typedef Dcpcrypt2::TDCP_blockcipher inherited;
	
private:
	StaticArray<System::Byte, 16> IV;
	StaticArray<System::Byte, 16> CV;
	void __fastcall IncCounter(void);
	
public:
	__classmethod virtual int __fastcall GetBlockSize();
	virtual void __fastcall Reset(void);
	virtual void __fastcall Burn(void);
	virtual void __fastcall SetIV(const void *Value);
	virtual void __fastcall GetIV(void *Value);
	virtual void __fastcall Init(const void *Key, unsigned Size, void * InitVector);
	virtual void __fastcall EncryptCBC(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCBC(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptCFB8bit(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCFB8bit(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptCFBblock(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCFBblock(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptOFB(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptOFB(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptCTR(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCTR(const void *Indata, void *Outdata, unsigned Size);
public:
	/* TDCP_blockcipher.Create */ inline __fastcall virtual TDCP_blockcipher128(Classes::TComponent* AOwner) : Dcpcrypt2::TDCP_blockcipher(AOwner) { }
	
public:
	/* TDCP_cipher.Destroy */ inline __fastcall virtual ~TDCP_blockcipher128(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dcpblockciphers */
using namespace Dcpblockciphers;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DcpblockciphersHPP
