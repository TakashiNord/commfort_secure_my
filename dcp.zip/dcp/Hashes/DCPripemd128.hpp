// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dcpripemd128.pas' rev: 21.00

#ifndef Dcpripemd128HPP
#define Dcpripemd128HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Dcpcrypt2.hpp>	// Pascal unit
#include <Dcpconst.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dcpripemd128
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDCP_ripemd128;
class PASCALIMPLEMENTATION TDCP_ripemd128 : public Dcpcrypt2::TDCP_hash
{
	typedef Dcpcrypt2::TDCP_hash inherited;
	
protected:
	unsigned LenHi;
	unsigned LenLo;
	unsigned Index;
	StaticArray<unsigned, 4> CurrentHash;
	StaticArray<System::Byte, 64> HashBuffer;
	void __fastcall Compress(void);
	
public:
	__classmethod virtual int __fastcall GetId();
	__classmethod virtual System::UnicodeString __fastcall GetAlgorithm();
	__classmethod virtual int __fastcall GetHashSize();
	__classmethod virtual bool __fastcall SelfTest();
	virtual void __fastcall Init(void);
	virtual void __fastcall Burn(void);
	virtual void __fastcall Update(const void *Buffer, unsigned Size);
	virtual void __fastcall Final(void *Digest);
public:
	/* TDCP_hash.Destroy */ inline __fastcall virtual ~TDCP_ripemd128(void) { }
	
public:
	/* TComponent.Create */ inline __fastcall virtual TDCP_ripemd128(Classes::TComponent* AOwner) : Dcpcrypt2::TDCP_hash(AOwner) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dcpripemd128 */
using namespace Dcpripemd128;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Dcpripemd128HPP
