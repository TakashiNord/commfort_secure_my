// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dcprc4.pas' rev: 21.00

#ifndef Dcprc4HPP
#define Dcprc4HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Dcpcrypt2.hpp>	// Pascal unit
#include <Dcpconst.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dcprc4
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDCP_rc4;
class PASCALIMPLEMENTATION TDCP_rc4 : public Dcpcrypt2::TDCP_cipher
{
	typedef Dcpcrypt2::TDCP_cipher inherited;
	
protected:
	StaticArray<System::Byte, 256> KeyData;
	StaticArray<System::Byte, 256> KeyOrg;
	
public:
	__classmethod virtual int __fastcall GetId();
	__classmethod virtual System::UnicodeString __fastcall GetAlgorithm();
	__classmethod virtual int __fastcall GetMaxKeySize();
	__classmethod virtual bool __fastcall SelfTest();
	virtual void __fastcall Init(const void *Key, unsigned Size, void * InitVector);
	virtual void __fastcall Reset(void);
	virtual void __fastcall Burn(void);
	virtual void __fastcall Encrypt(const void *InData, void *OutData, unsigned Size);
	virtual void __fastcall Decrypt(const void *InData, void *OutData, unsigned Size);
public:
	/* TDCP_cipher.Create */ inline __fastcall virtual TDCP_rc4(Classes::TComponent* AOwner) : Dcpcrypt2::TDCP_cipher(AOwner) { }
	/* TDCP_cipher.Destroy */ inline __fastcall virtual ~TDCP_rc4(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dcprc4 */
using namespace Dcprc4;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Dcprc4HPP
