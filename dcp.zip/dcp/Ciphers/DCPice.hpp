// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dcpice.pas' rev: 21.00

#ifndef DcpiceHPP
#define DcpiceHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Dcpcrypt2.hpp>	// Pascal unit
#include <Dcpconst.hpp>	// Pascal unit
#include <Dcpblockciphers.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dcpice
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDCP_customice;
class PASCALIMPLEMENTATION TDCP_customice : public Dcpblockciphers::TDCP_blockcipher64
{
	typedef Dcpblockciphers::TDCP_blockcipher64 inherited;
	
protected:
	unsigned rounds;
	StaticArray<StaticArray<unsigned, 3>, 32> ik_keysched;
	unsigned __fastcall f(unsigned p, unsigned sk);
	void __fastcall key_sched_build(Dcpcrypt2::Pwordarray kb, unsigned n, Dcpcrypt2::Pdwordarray keyrot);
	void __fastcall InitIce(const void *Key, unsigned Size, unsigned n);
	
public:
	virtual void __fastcall Burn(void);
	virtual void __fastcall EncryptECB(const void *InData, void *OutData);
	virtual void __fastcall DecryptECB(const void *InData, void *OutData);
	__fastcall virtual TDCP_customice(Classes::TComponent* AOwner);
public:
	/* TDCP_cipher.Destroy */ inline __fastcall virtual ~TDCP_customice(void) { }
	
};


class DELPHICLASS TDCP_ice;
class PASCALIMPLEMENTATION TDCP_ice : public TDCP_customice
{
	typedef TDCP_customice inherited;
	
protected:
	virtual void __fastcall InitKey(const void *Key, unsigned Size);
	
public:
	__classmethod virtual int __fastcall GetId();
	__classmethod virtual System::UnicodeString __fastcall GetAlgorithm();
	__classmethod virtual int __fastcall GetMaxKeySize();
	__classmethod virtual bool __fastcall SelfTest();
public:
	/* TDCP_customice.Create */ inline __fastcall virtual TDCP_ice(Classes::TComponent* AOwner) : TDCP_customice(AOwner) { }
	
public:
	/* TDCP_cipher.Destroy */ inline __fastcall virtual ~TDCP_ice(void) { }
	
};


class DELPHICLASS TDCP_thinice;
class PASCALIMPLEMENTATION TDCP_thinice : public TDCP_customice
{
	typedef TDCP_customice inherited;
	
protected:
	virtual void __fastcall InitKey(const void *Key, unsigned Size);
	
public:
	__classmethod virtual int __fastcall GetId();
	__classmethod virtual System::UnicodeString __fastcall GetAlgorithm();
	__classmethod virtual int __fastcall GetMaxKeySize();
	__classmethod virtual bool __fastcall SelfTest();
public:
	/* TDCP_customice.Create */ inline __fastcall virtual TDCP_thinice(Classes::TComponent* AOwner) : TDCP_customice(AOwner) { }
	
public:
	/* TDCP_cipher.Destroy */ inline __fastcall virtual ~TDCP_thinice(void) { }
	
};


class DELPHICLASS TDCP_ice2;
class PASCALIMPLEMENTATION TDCP_ice2 : public TDCP_customice
{
	typedef TDCP_customice inherited;
	
protected:
	virtual void __fastcall InitKey(const void *Key, unsigned Size);
	
public:
	__classmethod virtual int __fastcall GetId();
	__classmethod virtual System::UnicodeString __fastcall GetAlgorithm();
	__classmethod virtual int __fastcall GetMaxKeySize();
	__classmethod virtual bool __fastcall SelfTest();
public:
	/* TDCP_customice.Create */ inline __fastcall virtual TDCP_ice2(Classes::TComponent* AOwner) : TDCP_customice(AOwner) { }
	
public:
	/* TDCP_cipher.Destroy */ inline __fastcall virtual ~TDCP_ice2(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dcpice */
using namespace Dcpice;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DcpiceHPP
