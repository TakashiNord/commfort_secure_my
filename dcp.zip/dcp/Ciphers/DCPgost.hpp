// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dcpgost.pas' rev: 21.00

#ifndef DcpgostHPP
#define DcpgostHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Dcpcrypt2.hpp>	// Pascal unit
#include <Dcpconst.hpp>	// Pascal unit
#include <Dcpblockciphers.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dcpgost
{
//-- type declarations -------------------------------------------------------
class DELPHICLASS TDCP_gost;
class PASCALIMPLEMENTATION TDCP_gost : public Dcpblockciphers::TDCP_blockcipher64
{
	typedef Dcpblockciphers::TDCP_blockcipher64 inherited;
	
protected:
	StaticArray<unsigned, 8> KeyData;
	virtual void __fastcall InitKey(const void *Key, unsigned Size);
	
public:
	__classmethod virtual int __fastcall GetId();
	__classmethod virtual System::UnicodeString __fastcall GetAlgorithm();
	__classmethod virtual int __fastcall GetMaxKeySize();
	__classmethod virtual bool __fastcall SelfTest();
	virtual void __fastcall Burn(void);
	virtual void __fastcall EncryptECB(const void *InData, void *OutData);
	virtual void __fastcall DecryptECB(const void *InData, void *OutData);
public:
	/* TDCP_blockcipher.Create */ inline __fastcall virtual TDCP_gost(Classes::TComponent* AOwner) : Dcpblockciphers::TDCP_blockcipher64(AOwner) { }
	
public:
	/* TDCP_cipher.Destroy */ inline __fastcall virtual ~TDCP_gost(void) { }
	
};


//-- var, const, procedure ---------------------------------------------------

}	/* namespace Dcpgost */
using namespace Dcpgost;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DcpgostHPP
