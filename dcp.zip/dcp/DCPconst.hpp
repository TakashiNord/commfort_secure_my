// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dcpconst.pas' rev: 21.00

#ifndef DcpconstHPP
#define DcpconstHPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dcpconst
{
//-- type declarations -------------------------------------------------------
//-- var, const, procedure ---------------------------------------------------
#define DCPcipherpage L"DCPciphers"
#define DCPhashpage L"DCPhashes"
static const ShortInt DCP_rc2 = 0x1;
static const ShortInt DCP_sha1 = 0x2;
static const ShortInt DCP_rc5 = 0x3;
static const ShortInt DCP_rc6 = 0x4;
static const ShortInt DCP_blowfish = 0x5;
static const ShortInt DCP_twofish = 0x6;
static const ShortInt DCP_cast128 = 0x7;
static const ShortInt DCP_gost = 0x8;
static const ShortInt DCP_rijndael = 0x9;
static const ShortInt DCP_ripemd160 = 0xa;
static const ShortInt DCP_misty1 = 0xb;
static const ShortInt DCP_idea = 0xc;
static const ShortInt DCP_mars = 0xd;
static const ShortInt DCP_haval = 0xe;
static const ShortInt DCP_cast256 = 0xf;
static const ShortInt DCP_md5 = 0x10;
static const ShortInt DCP_md4 = 0x11;
static const ShortInt DCP_tiger = 0x12;
static const ShortInt DCP_rc4 = 0x13;
static const ShortInt DCP_ice = 0x14;
static const ShortInt DCP_thinice = 0x15;
static const ShortInt DCP_ice2 = 0x16;
static const ShortInt DCP_des = 0x17;
static const ShortInt DCP_3des = 0x18;
static const ShortInt DCP_tea = 0x19;
static const ShortInt DCP_serpent = 0x1a;
static const ShortInt DCP_ripemd128 = 0x1b;
static const ShortInt DCP_sha256 = 0x1c;
static const ShortInt DCP_sha384 = 0x1d;
static const ShortInt DCP_sha512 = 0x1e;

}	/* namespace Dcpconst */
using namespace Dcpconst;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// DcpconstHPP
