// CodeGear C++Builder
// Copyright (c) 1995, 2009 by Embarcadero Technologies, Inc.
// All rights reserved

// (DO NOT EDIT: machine generated header) 'Dcpcrypt2.pas' rev: 21.00

#ifndef Dcpcrypt2HPP
#define Dcpcrypt2HPP

#pragma delphiheader begin
#pragma option push
#pragma option -w-      // All warnings off
#pragma option -Vx      // Zero-length empty class member functions
#pragma pack(push,8)
#include <System.hpp>	// Pascal unit
#include <Sysinit.hpp>	// Pascal unit
#include <Classes.hpp>	// Pascal unit
#include <Sysutils.hpp>	// Pascal unit
#include <Dcpconst.hpp>	// Pascal unit
#include <Dcpbase64.hpp>	// Pascal unit

//-- user supplied -----------------------------------------------------------

namespace Dcpcrypt2
{
//-- type declarations -------------------------------------------------------
typedef System::Byte *Pbyte;

typedef System::Word *Pword;

typedef unsigned *Pdword;

typedef __int64 *Pint64;

typedef unsigned dword;

typedef StaticArray<System::Word, 19384> Twordarray;

typedef Twordarray *Pwordarray;

typedef StaticArray<unsigned, 8192> Tdwordarray;

typedef Tdwordarray *Pdwordarray;

class DELPHICLASS EDCP_hash;
class PASCALIMPLEMENTATION EDCP_hash : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
public:
	/* Exception.Create */ inline __fastcall EDCP_hash(const System::UnicodeString Msg) : Sysutils::Exception(Msg) { }
	/* Exception.CreateFmt */ inline __fastcall EDCP_hash(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall EDCP_hash(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall EDCP_hash(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall EDCP_hash(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall EDCP_hash(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EDCP_hash(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EDCP_hash(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~EDCP_hash(void) { }
	
};


class DELPHICLASS TDCP_hash;
class PASCALIMPLEMENTATION TDCP_hash : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
protected:
	bool fInitialized;
	void __fastcall DeadInt(int Value);
	void __fastcall DeadStr(System::UnicodeString Value);
	
private:
	int __fastcall _GetId(void);
	System::UnicodeString __fastcall _GetAlgorithm(void);
	int __fastcall _GetHashSize(void);
	
public:
	__property bool Initialized = {read=fInitialized, nodefault};
	__classmethod virtual int __fastcall GetId();
	__classmethod virtual System::UnicodeString __fastcall GetAlgorithm();
	__classmethod virtual int __fastcall GetHashSize();
	__classmethod virtual bool __fastcall SelfTest();
	virtual void __fastcall Init(void);
	virtual void __fastcall Final(void *Digest);
	virtual void __fastcall Burn(void);
	virtual void __fastcall Update(const void *Buffer, unsigned Size);
	void __fastcall UpdateStream(Classes::TStream* Stream, unsigned Size);
	void __fastcall UpdateStr(const System::AnsiString Str)/* overload */;
	void __fastcall UpdateStr(const System::UnicodeString Str)/* overload */;
	__fastcall virtual ~TDCP_hash(void);
	
__published:
	__property int Id = {read=_GetId, write=DeadInt, nodefault};
	__property System::UnicodeString Algorithm = {read=_GetAlgorithm, write=DeadStr};
	__property int HashSize = {read=_GetHashSize, write=DeadInt, nodefault};
public:
	/* TComponent.Create */ inline __fastcall virtual TDCP_hash(Classes::TComponent* AOwner) : Classes::TComponent(AOwner) { }
	
};


typedef TMetaClass* TDCP_hashclass;

class DELPHICLASS EDCP_cipher;
class PASCALIMPLEMENTATION EDCP_cipher : public Sysutils::Exception
{
	typedef Sysutils::Exception inherited;
	
public:
	/* Exception.Create */ inline __fastcall EDCP_cipher(const System::UnicodeString Msg) : Sysutils::Exception(Msg) { }
	/* Exception.CreateFmt */ inline __fastcall EDCP_cipher(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : Sysutils::Exception(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall EDCP_cipher(int Ident)/* overload */ : Sysutils::Exception(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall EDCP_cipher(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : Sysutils::Exception(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall EDCP_cipher(const System::UnicodeString Msg, int AHelpContext) : Sysutils::Exception(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall EDCP_cipher(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : Sysutils::Exception(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EDCP_cipher(int Ident, int AHelpContext)/* overload */ : Sysutils::Exception(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EDCP_cipher(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : Sysutils::Exception(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~EDCP_cipher(void) { }
	
};


class DELPHICLASS TDCP_cipher;
class PASCALIMPLEMENTATION TDCP_cipher : public Classes::TComponent
{
	typedef Classes::TComponent inherited;
	
protected:
	bool fInitialized;
	void __fastcall DeadInt(int Value);
	void __fastcall DeadStr(System::UnicodeString Value);
	
private:
	int __fastcall _GetId(void);
	System::UnicodeString __fastcall _GetAlgorithm(void);
	int __fastcall _GetMaxKeySize(void);
	
public:
	__property bool Initialized = {read=fInitialized, nodefault};
	__classmethod virtual int __fastcall GetId();
	__classmethod virtual System::UnicodeString __fastcall GetAlgorithm();
	__classmethod virtual int __fastcall GetMaxKeySize();
	__classmethod virtual bool __fastcall SelfTest();
	virtual void __fastcall Init(const void *Key, unsigned Size, void * InitVector);
	void __fastcall InitStr(const System::AnsiString Key, TDCP_hashclass HashType)/* overload */;
	void __fastcall InitStr(const System::UnicodeString Key, TDCP_hashclass HashType)/* overload */;
	virtual void __fastcall Burn(void);
	virtual void __fastcall Reset(void);
	virtual void __fastcall Encrypt(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall Decrypt(const void *Indata, void *Outdata, unsigned Size);
	unsigned __fastcall EncryptStream(Classes::TStream* InStream, Classes::TStream* OutStream, unsigned Size);
	unsigned __fastcall DecryptStream(Classes::TStream* InStream, Classes::TStream* OutStream, unsigned Size);
	virtual System::AnsiString __fastcall EncryptString(const System::AnsiString Str)/* overload */;
	virtual System::AnsiString __fastcall DecryptString(const System::AnsiString Str)/* overload */;
	virtual System::UnicodeString __fastcall EncryptString(const System::UnicodeString Str)/* overload */;
	virtual System::UnicodeString __fastcall DecryptString(const System::UnicodeString Str)/* overload */;
	__fastcall virtual TDCP_cipher(Classes::TComponent* AOwner);
	__fastcall virtual ~TDCP_cipher(void);
	
__published:
	__property int Id = {read=_GetId, write=DeadInt, nodefault};
	__property System::UnicodeString Algorithm = {read=_GetAlgorithm, write=DeadStr};
	__property int MaxKeySize = {read=_GetMaxKeySize, write=DeadInt, nodefault};
};


typedef TMetaClass* TDCP_cipherclass;

#pragma option push -b-
enum TDCP_ciphermode { cmCBC, cmCFB8bit, cmCFBblock, cmOFB, cmCTR };
#pragma option pop

class DELPHICLASS EDCP_blockcipher;
class PASCALIMPLEMENTATION EDCP_blockcipher : public EDCP_cipher
{
	typedef EDCP_cipher inherited;
	
public:
	/* Exception.Create */ inline __fastcall EDCP_blockcipher(const System::UnicodeString Msg) : EDCP_cipher(Msg) { }
	/* Exception.CreateFmt */ inline __fastcall EDCP_blockcipher(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size) : EDCP_cipher(Msg, Args, Args_Size) { }
	/* Exception.CreateRes */ inline __fastcall EDCP_blockcipher(int Ident)/* overload */ : EDCP_cipher(Ident) { }
	/* Exception.CreateResFmt */ inline __fastcall EDCP_blockcipher(int Ident, System::TVarRec const *Args, const int Args_Size)/* overload */ : EDCP_cipher(Ident, Args, Args_Size) { }
	/* Exception.CreateHelp */ inline __fastcall EDCP_blockcipher(const System::UnicodeString Msg, int AHelpContext) : EDCP_cipher(Msg, AHelpContext) { }
	/* Exception.CreateFmtHelp */ inline __fastcall EDCP_blockcipher(const System::UnicodeString Msg, System::TVarRec const *Args, const int Args_Size, int AHelpContext) : EDCP_cipher(Msg, Args, Args_Size, AHelpContext) { }
	/* Exception.CreateResHelp */ inline __fastcall EDCP_blockcipher(int Ident, int AHelpContext)/* overload */ : EDCP_cipher(Ident, AHelpContext) { }
	/* Exception.CreateResFmtHelp */ inline __fastcall EDCP_blockcipher(System::PResStringRec ResStringRec, System::TVarRec const *Args, const int Args_Size, int AHelpContext)/* overload */ : EDCP_cipher(ResStringRec, Args, Args_Size, AHelpContext) { }
	/* Exception.Destroy */ inline __fastcall virtual ~EDCP_blockcipher(void) { }
	
};


class DELPHICLASS TDCP_blockcipher;
class PASCALIMPLEMENTATION TDCP_blockcipher : public TDCP_cipher
{
	typedef TDCP_cipher inherited;
	
protected:
	TDCP_ciphermode fCipherMode;
	virtual void __fastcall InitKey(const void *Key, unsigned Size);
	
private:
	int __fastcall _GetBlockSize(void);
	
public:
	__classmethod virtual int __fastcall GetBlockSize();
	virtual void __fastcall SetIV(const void *Value);
	virtual void __fastcall GetIV(void *Value);
	virtual void __fastcall Encrypt(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall Decrypt(const void *Indata, void *Outdata, unsigned Size);
	virtual System::AnsiString __fastcall EncryptString(const System::AnsiString Str)/* overload */;
	virtual System::AnsiString __fastcall DecryptString(const System::AnsiString Str)/* overload */;
	virtual System::UnicodeString __fastcall EncryptString(const System::UnicodeString Str)/* overload */;
	virtual System::UnicodeString __fastcall DecryptString(const System::UnicodeString Str)/* overload */;
	virtual void __fastcall EncryptECB(const void *Indata, void *Outdata);
	virtual void __fastcall DecryptECB(const void *Indata, void *Outdata);
	virtual void __fastcall EncryptCBC(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCBC(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptCFB8bit(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCFB8bit(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptCFBblock(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCFBblock(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptOFB(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptOFB(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall EncryptCTR(const void *Indata, void *Outdata, unsigned Size);
	virtual void __fastcall DecryptCTR(const void *Indata, void *Outdata, unsigned Size);
	__fastcall virtual TDCP_blockcipher(Classes::TComponent* AOwner);
	
__published:
	__property int BlockSize = {read=_GetBlockSize, write=DeadInt, nodefault};
	__property TDCP_ciphermode CipherMode = {read=fCipherMode, write=fCipherMode, default=0};
public:
	/* TDCP_cipher.Destroy */ inline __fastcall virtual ~TDCP_blockcipher(void) { }
	
};


typedef TMetaClass* TDCP_blockcipherclass;

//-- var, const, procedure ---------------------------------------------------
extern PACKAGE void __fastcall XorBlock(void *InData1, void *InData2, unsigned Size);

}	/* namespace Dcpcrypt2 */
using namespace Dcpcrypt2;
#pragma pack(pop)
#pragma option pop

#pragma delphiheader end.
//-- end unit ----------------------------------------------------------------
#endif	// Dcpcrypt2HPP
